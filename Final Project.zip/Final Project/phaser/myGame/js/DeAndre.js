//var CurrentTextID = Alarm;
var interactText;
var cutscene = false;

function DeAndre(game, key, frame){
	Phaser.Sprite.call(this, game, 0, 390, key, frame);

	this.anchor.set(0.5);
	
	game.physics.enable(this);
	this.body.collideWorldBounds = true;
//    this.body.checkCollision = {up: true, down: true, left:true, right: false};
	this.enableBody = true;

}

DeAndre.prototype = Object.create(Phaser.Sprite.prototype);
DeAndre.prototype.constructor = DeAndre;



DeAndre.prototype.update = function(){
	if(game.input.keyboard.isDown(Phaser.Keyboard.A) && cutscene == false){
		this.body.velocity.x = -1000;
	}else if(game.input.keyboard.isDown(Phaser.Keyboard.D) && cutscene == false){
		this.body.velocity.x = 1000;
				
	}else{
		this.body.velocity.x = 0;
		this.body.velocity.y = 0;
	}

	if(cutscene == true && game.input.keyboard.justPressed(Phaser.Keyboard.SPACEBAR)){
		currentDialogue(currentText, currentScript);
	}


	

	// if(game.input.keyboard.justPressed(Phaser.Keyboard.R)){
	// 	this.startConversation("alarm");
	// }
			
}

function Interact(Interactable){
	currentDialogue(currentText);
}